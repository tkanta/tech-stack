const express = require('express')
const expressip = require('express-ip')
const bodyParser = require('body-parser')
const toobusy = require('node-toobusy')
const helmet = require('helmet')
const elsRouter = require('./routes/els-router')
const nextNavRouter = require('./routes/nextnav-router')
const consumerRouter = require('./routes/consumer-router')
const statusRouter = require('./routes/status-router')
const omService = require('./routes/om-service-router')
const { port, statusPath, baseUrl } = require('./config/config')
const resUtil = require('./util/responseUtil')
const constants = require('./util/constants')
const kafka = require('./voyager/kafka')
var alarm = null;

const app = express()

app.use(express.json())

// Bad request handling
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
      kafka.omPostFailure.incr();
      const errResp = resUtil.createErrorResponse(400, constants.MALFORMED_REQUEST, err.message)
      kafka.eventLogger.logEvent('ZAXIS-WronglyFormattedJSON','Wrongly Formatted JSON :' + errResp.errors);
      return res.status(400).send(errResp); 
  }
  next();
});

app.disable('x-powered-by')

app.set('trust proxy', true)

app.use(function (req, res, next) {
  if (toobusy()) {
    //res.send(503, "I'm busy right now, sorry.")
    res.status(503).send("I'm busy right now, sorry.")
    if(alarm == null) {
      alarm = kafka.eventLogger.createAlarm('ZAXIS-ServiceNotAvailable');
      alarm.raise('Service not responding at the moment');
    }
  }
  else {
    if(alarm != null){
      alarm.clear('Service is responding');
      alarm = null;
    }
    next()
  }
})

app.use(helmet())

app.use(expressip().getIpInfoMiddleware)

app.use(bodyParser.urlencoded({
  extended: false,
  // verify: function (req, res, buf, encoding) {
  //   if (buf && buf.length) {
  //     req.rawBody = buf.toString(encoding || 'utf8')
  //   }
  // }
}))

app.use(baseUrl, elsRouter)

app.use(baseUrl, nextNavRouter)

app.use(baseUrl, consumerRouter)

app.use(baseUrl, statusRouter)

app.use(baseUrl, omService)

app.listen(port, () => {
    console.log(`Server is listening on port: ${port}`)
});

