
const reqParser = async (req, res, next) => {
    
    req.rawBody = Object.keys(req.body).map(function(k) {
        return k + '=' + req.body[k]
    }).join('&');

    next();
}

module.exports = reqParser