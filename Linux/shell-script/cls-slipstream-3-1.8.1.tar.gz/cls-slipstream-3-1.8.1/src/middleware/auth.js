const csClient = require('../cache/redisCache')
const constants = require('../util/constants')
const resUtil = require('../util/responseUtil')
//const bcrypt  = require('bcrypt');
const clsUtil = require('../util/clsUtil')
const kafka = require('../voyager/kafka')
const logger = require('../util/logUtil')

const auth = async (req, res, next) => {
    if (!req.headers.authorization) {
        req.checkContinue = false;
        
        const errResp = resUtil.createErrorResponse(401, constants.UNAUTHORIZED, constants.MISSING_AUTHORIZATION_HEADER)
        logger.collectionLog(req, 'CONN', " ", "", "401", "FAILURE", JSON.stringify(errResp));
        res.set("Content-Type", "application/json").status(401).send(errResp)
        return;
    }

    const authToken =  req.headers.authorization.split(' ')[1];
    const authCreds = Buffer.from(authToken, 'base64').toString('ascii');
    const [authUser, basicPass] = authCreds.split(':');
    
    var basicUser = authUser.toLowerCase();

    if (basicUser == "" || basicPass == "") {
        req.checkContinue = false;

        const errResp = resUtil.createErrorResponse(401, constants.UNAUTHORIZED, constants.MISSING_USERNAME_OR_PASSWORD)
        logger.collectionLog(req, 'CONN', basicUser, "", "401", "FAILURE", JSON.stringify(errResp));
        res.set("Content-Type", "application/json").status(401).send(errResp)
        return;
    }

    var authStatus = false;

    let result = {};

    try{
        result = await csClient.getUserDetails(basicUser);
    }catch(err){
        const errResp = resUtil.createErrorResponse(500, constants.INTERNAL_SERVER_ERROR, err.message)
        logger.collectionLog(req, req.method, "", "", "500", "FAILURE", JSON.stringify(errResp));
        res.set("Content-Type", "application/json").status(500).send(errResp)
        return
    }
    

    if (!clsUtil.isEmptyObject(result)) {
        //authStatus = await bcrypt.compare(basicPass, result.pass);
        var pwd = Buffer.from(result.pass, 'base64').toString('ascii'); 
        authStatus = basicPass == pwd;
    } 
    
    if (!authStatus) {

        logger.collectionLog(req, 'CONN', basicUser, "", "401", "FAILURE", "Auth Failed");
        req.checkContinue = false;
        const errResp = resUtil.createErrorResponse(401, constants.UNAUTHORIZED, constants.INVALID_USERNAME_OR_PASSWORD)
        kafka.eventLogger.logEvent('ZAXIS-BadOrInvalidCredentials','Bad or Invalid Credentials :'+errResp.errors);

        res.set("Content-Type", "application/json").status(401).send(errResp)
        return;
    } 

    req.loggedin_user = basicUser;
    next();
}

module.exports = auth