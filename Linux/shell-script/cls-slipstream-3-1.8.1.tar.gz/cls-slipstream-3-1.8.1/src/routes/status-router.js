const express = require('express')
const router = new express.Router()
const config = require('../config/config')
const auth = require('../middleware/auth')
const os = require('os')
const clsUtil = require('../util/clsUtil')
const logger = require('../util/logUtil')
const pkginfo = require('../../package')

router.get(config.statusPath, auth, async (req, res) => {
    var uptime = clsUtil.getUptime();
    var thishost=os.hostname();
    
    var collectionStats = {
      "serviceName": config.hcs_desc,
      "hostName"   : thishost,
      "reportDate" : new Date(),
      "uptime"     : uptime
    };
    res.send(collectionStats)
})

module.exports = router
