const express = require('express')
const router = new express.Router()
const { elsPath, mateRetryCount } = require('../config/config')
const elsHmacValidate = require('../validation/els-validate')
const elsModel = require('../model/els-model')
const resUtil = require('../util/responseUtil')
const constants = require('../util/constants')
const logger = require('../util/logUtil')
const httpUtils = require('../util/httpUtils')
const clsUtil = require('../util/clsUtil')
const kafka = require('../voyager/kafka')
const reqParser = require('../middleware/req-parser')
const ldrUtil = require('../util/ldrUtil')

router.post(elsPath, reqParser, async (req, res) => {

    kafka.omPostReceived.incr();
    //end response immediately after receiving the ELS request
    res.end()
    if ((parseFloat(req.body.location_latitude) === 0 && parseFloat(req.body.location_longitude) === 0) || (
        parseFloat(req.body.location_accuracy) === 0 || parseFloat(req.body.location_confidence) === 0)) {
        logger.printDebug('ELS Request - Received with lat: ' + req.body.location_latitude + ', long: ' + req.body.location_longitude + ', accuracy: ' + req.body.location_accuracy + ', confidence: ' + req.body.location_confidence);
        ldrUtil.createAndSendLDRfromELS(req, constants.BAD_REQUEST_CODE, constants.NO_LOCATION_AVAILABLE, false);
        return;
    }
    //store collection server mate urls for further use
    //clsUtil.updateMateUrl(req)

    // Send request to mate servers
    let syncWithMate = req.header('sync');
    if (typeof syncWithMate === 'undefined' || syncWithMate == 'true') {
        if (clsUtil.getMateUrls() && clsUtil.getMateUrls().length > 0) {
            clsUtil.getMateUrls().forEach(url => {
                if (url) {
                    let mateUrl = url + req.originalUrl;
                    httpUtils.postJsonWithRetry(req, mateUrl, mateRetryCount)
                }
            });
        }
    }

    //validate hmac 
    if (elsHmacValidate(req.body.hmac, req.rawBody)) {
        try {
            elsModel.saveModel(req, ldrUtil.createAndSendLDRfromELS)
            kafka.omPostSuccess.incr();
        } catch (err) {
            kafka.omPostFailure.incr();
            const errResp = resUtil.createErrorResponse(constants.INTERNAL_SERVER_ERROR_CODE, constants.INTERNAL_SERVER_ERROR, err.message)
            logger.collectionLog(req, 'POST', "", "", "500", "FAILURE", errResp);
        }
    } else {
        ldrUtil.createAndSendLDRfromELS(req, constants.BAD_REQUEST_CODE, constants.VALIDATION_FAILED, false);
        kafka.omPostFailure.incr();
        const errResp = resUtil.createErrorResponse(constants.BAD_REQUEST_CODE, constants.HMAC_VALIDATION_ERROR, constants.HMAC_VALIDATION_ERROR)
        logger.collectionLog(req, 'POST', "", "", "400", "FAILURE", errResp);
        logger.collectionLog(req, 'POST', "", "", "400", "FAILURE", 'Request Message: '+req.rawBody);
    }

})

module.exports = router