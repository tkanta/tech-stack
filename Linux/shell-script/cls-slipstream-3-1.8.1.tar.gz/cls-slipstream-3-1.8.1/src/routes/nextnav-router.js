const express = require('express')
const router = new express.Router()
const config = require('../config/config')
const { validateImsi, validateImei, validateZaxis } = require('../validation/nextnav-validate')
const auth = require('../middleware/auth')
const resUtil = require('../util/responseUtil')
const constants = require('../util/constants')
const clsUtil = require('../util/clsUtil')
const nextNavModel = require('../model/nextnav-model')
const kafka = require('../voyager/kafka')
var   voyager  = require('node-core');
const logger = require('../util/logUtil')
const util    = require('util');
const ldrUtil = require('../util/ldrUtil')
/**
 * Post URI for zaxis
 */
router.post(config.zaxisPath, auth, async (req, res) => {
    
    kafka.omPostReceived.incr();

    const payload = req.body

    //check data 
    if(clsUtil.isEmptyObject(payload)){
        kafka.omPostFailure.incr();
        const errResp = resUtil.createErrorResponse(400, constants.MALFORMED_REQUEST, constants.EMPTY_REQUEST_BODY)
        res.set("Content-Type", "application/json").status(400).send(errResp)
        return
    }

    //Validation of IMEI, IMSI, ZAxis Req
    let validZaxis = validateZaxis(payload);
    
    if(!validZaxis){
        kafka.omPostFailure.incr();
        ldrUtil.createAndSendLDRfromNNav(req, constants.BAD_REQUEST_CODE, constants.VALIDATION_FAILED, false);
        const errResp = resUtil.createErrorResponse(400, constants.MALFORMED_REQUEST, null)
        validateZaxis.errors.forEach(function(item) {
            var message = "";
            if (item.keyword === 'required') message = 'Missing parameter ' + item.params.missingProperty
            else message = 'zaxis' + item.dataPath + ': ' + item.message
            errResp.errors.push(message);
          });
          kafka.eventLogger.logEvent('ZAXIS-InvalidFieldDataTypes','Invalid data types for JSON Fields :' + errResp.errors);
        
        logger.collectionLog(req,'POST',"","","400", "FAILURE", JSON.stringify(errResp));
        res.set("Content-Type", "application/json").status(400).send(errResp)
        return
    }
    
    try{
        nextNavModel.saveModel(req, ldrUtil.createAndSendLDRfromNNav)
        kafka.omPostSuccess.incr();
        res.set("Content-Type", "text/plain").status(204).send();
    }catch(err){
        kafka.omPostFailure.incr();
        const errResp = resUtil.createErrorResponse(500, constants.INTERNAL_SERVER_ERROR, err.message)
        logger.collectionLog(req,'POST',"","","500", "FAILURE", JSON.stringify(errResp));
        res.set("Content-Type", "application/json").status(500).send(errResp)
    }
})

/**
 * Get URI for zaxis
 */
router.get(config.zaxisPath, auth, async (req, res) => {

    kafka.omGetReceived.incr();

    const imei = req.query['imei']
    const imsi = req.query['imsi']

    let addrKey, addrVal, errResp, addrValid, addrKeyType;

    if(imsi){
        addrValid = validateImsi(imsi);
        addrVal = imsi
        addrKey = constants.ZAXIS_IMSI_PREFIX + imsi
        addrKeyType = 'IMSI->'
    }else if(imei){
        addrValid = validateImei(imei);
        addrVal = imei
        addrKey = clsUtil.getImeiKey(constants.ZAXIS_IMEI_PREFIX, imei)
        addrKeyType = 'IMEI->'
    } 

    if(!addrValid){
        kafka.omGetFailure.incr();
        errResp = resUtil.createErrorResponse(400, constants.BAD_REQUEST, constants.MISSING_OR_BADLY_FORMED + addrKeyType + addrVal)
        logger.collectionLog(req,'GET',"","","400", "FAILURE", JSON.stringify(errResp));
        kafka.eventLogger.logEvent('ZAXIS-BadRequest','Bad Request :'+errResp.errors);

        res.set("Content-Type", "application/json").status(400).send(errResp)
        return
    }

    try{
        
        const response = await nextNavModel.getModel(addrKey)
        kafka.omGetSuccess.incr(); 
        res.set("Content-Type", "application/json").status(200).send(response)

    }catch(err){
        kafka.omGetFailure.incr();
        const errResp = resUtil.createErrorResponse(404, constants.NO_DATA, constants.NO_VALID_DATA_FOUND_FOR + addrKeyType + addrVal)
        logger.collectionLog(req,'GET',"","","404", "FAILURE", JSON.stringify(errResp));
        kafka.eventLogger.logEvent('ZAXIS-NoDataFound','Error :'+errResp.errors);
        res.set("Content-Type", "application/json").status(404).send(errResp)
    }
})

module.exports = router