const express = require('express')
const router = new express.Router()
const config = require('../config/config')
const auth = require('../middleware/auth')
const consumerModel = require('../model/consumer-model')
const { validateImsi, validateImei } = require('../validation/nextnav-validate')
const validateMsisdn = require('../validation/msisdn-validate')
const resUtil = require('../util/responseUtil')
const constants = require('../util/constants')
const logger = require('../util/logUtil')
const util    = require('util');
const kafka = require('../voyager/kafka')

/**
 * Get URI for Consumer API
 */
router.get(config.consumerPath, auth, async (req, res) => {

    kafka.omGetReceived.incr();

    const imei = req.query['imei']
    const imsi = req.query['imsi']
    const msisdn = req.query['msisdn']
    const source = (req.query['source']) ? req.query['source'] : '';
    const native = (req.query['native']) ? req.query['native'] : 'false';

    let addrKey, addrVal, addrValid, addrKeyType;

    if(imsi){
        addrValid = validateImsi(imsi);
        addrVal = imsi
        addrKey = 'imsi'
        addrKeyType = 'IMSI->'
    }else if(imei){
        addrValid = validateImei(imei);
        addrVal = imei
        addrKey = 'imei'
        addrKeyType = 'IMEI->'
    }else if(msisdn){
        addrValid = validateMsisdn(msisdn);
        addrVal = msisdn
        addrKey = 'msisdn'
        addrKeyType = 'MSISDN->'
    } 

    

    if(!addrValid){
        kafka.omGetFailure.incr();
        const errResp = resUtil.createErrorResponse(400, constants.BAD_REQUEST, constants.MISSING_OR_BADLY_FORMED + addrKeyType + addrVal)
        logger.collectionLog(req,'GET',"","","400", "FAILURE", JSON.stringify(errResp));
        kafka.eventLogger.logEvent('ZAXIS-BadRequest','Error:'+errResp.errors);
        res.set("Content-Type", "application/json").status(400).send(errResp)
        return
    }

    var errorSourceOrNative = false;
    if(source){
        var sourceList = ['NNAV', 'ELS', 'HELO', 'AML', ''];
        var valid = sourceList.includes(source, 0);
        if(!valid)
            errorSourceOrNative = true;
    }
    
    if(native){
        var nativeList = ['true', 'false'];
        var valid = nativeList.includes(native, 0);
        if(!valid){
            errorSourceOrNative = true;
        }
    } 

    if(errorSourceOrNative){
        kafka.omGetFailure.incr();
        const errResp = resUtil.createErrorResponse(400, constants.BAD_REQUEST, constants.BADLY_FORMED + ' source or native value')
        logger.collectionLog(req,'GET',"","","400", "FAILURE", JSON.stringify(errResp));
        kafka.eventLogger.logEvent('ZAXIS-BadRequest','Error :'+errResp.errors);
        res.set("Content-Type", "application/json").status(400).send(errResp)
        return
    }
    

    try{
        const response = await consumerModel.getConsumerData(addrKey, addrVal, source, native)
        if(!response || response == '{}') {
            throw new Error('Empty response') 
        }

        kafka.omGetSuccess.incr(); 
        res.set("Content-Type", "application/json").status(200).send(response)

    }catch(err){
        kafka.omGetFailure.incr();
        const errResp = resUtil.createErrorResponse(404, constants.NO_DATA, constants.NO_VALID_DATA_FOUND_FOR + addrKeyType + addrVal)
        logger.collectionLog(req,'GET',"","","404", "FAILURE", JSON.stringify(errResp));
        kafka.eventLogger.logEvent('ZAXIS-NoDataFound','Error :'+errResp.errors);
        res.set("Content-Type", "application/json").status(404).send(errResp)
    }
})

module.exports = router