const express = require('express')
const router = new express.Router()
const config = require('../config/config')
const auth = require('../middleware/auth')
const os = require('os')
const clsUtil = require('../util/clsUtil')
const logger = require('../util/logUtil')
const pkginfo = require('../../package')
const kafka = require('../voyager/kafka')

router.get(config.omServicePath, auth, async (req, res) => {
    
    const type = req.query['type'];
    var status = "";
    if(type === 'stop'){
      kafka.omCounters.stopStartMetrics(false);
      status = 'stoped';    
    } else {
      kafka.omCounters.stopStartMetrics(true);
      status = 'started';
    }
    var statusMessage = {
      "serviceName": "Om Service: "+status
    };
    res.send(statusMessage)
})

module.exports = router
