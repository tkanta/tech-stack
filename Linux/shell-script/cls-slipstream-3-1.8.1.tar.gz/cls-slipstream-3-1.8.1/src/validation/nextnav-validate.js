const Ajv     = require('ajv');
const fs      = require('fs');
const path    = require('path');

//
// Placeholder for ajv validation constructors
//
var ajv = null;
var validateImsi = null;
var validateImei = null;
var validateZaxis = null;

var imsiSchema  = {};
var imeiSchema  = {};
var zaxisSchema = {};

 // Import schemas for validation and remapping
imsiSchema  = JSON.parse(fs.readFileSync(path.join(__dirname, '/schema/imsi.schema'),  'utf8'));
imeiSchema  = JSON.parse(fs.readFileSync(path.join(__dirname, '/schema/imei.schema'),  'utf8'));
zaxisSchema = JSON.parse(fs.readFileSync(path.join(__dirname, '/schema/zaxis.schema'), 'utf8'));


ajv = Ajv({
    allErrors: true,
    schemas: [
      imsiSchema,
      imeiSchema,
      zaxisSchema
    ]
  });

validateImsi  = ajv.getSchema("imsiSchema");
validateImei  = ajv.getSchema("imeiSchema");
validateZaxis = ajv.getSchema("zaxisSchema"); 

module.exports = { validateImsi, validateImei, validateZaxis }