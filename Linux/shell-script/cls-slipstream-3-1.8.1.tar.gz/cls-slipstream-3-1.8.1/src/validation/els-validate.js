const crypto = require('crypto')
const config = require('../config/config')
const { secret, hashAlgorithm, bypassHmacValidation } = config.hmac

require('buffer-equal-constant-time').install()

function elsHmacValidate (hmac, rawBody) {
  if(bypassHmacValidation)
    return true
  
  if(hmac == undefined)
    return false;

  const hmacGenerator = crypto.createHmac(hashAlgorithm, secret)
  hmacGenerator.write(rawBody.split('&hmac=')[0])
  hmacGenerator.end()
  const hmacGenerated = hmacGenerator.read()
  return hmacGenerated.equal(Buffer.from(hmac, 'hex'))
}

module.exports = elsHmacValidate
