const numbers = /^([0-9]+)$/;

function validateMsisdn (msisdn) {
    return msisdn && numbers.test(msisdn)
}

module.exports = validateMsisdn