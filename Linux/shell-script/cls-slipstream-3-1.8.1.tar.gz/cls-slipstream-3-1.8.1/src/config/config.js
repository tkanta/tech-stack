const fs      = require('fs');
const { exit } = require('process');
var configPath = process.env.SHARED_VOLUME_PATH;
if(!configPath)
{
    console.error("Unable to load Config file, Reqd Env Variable not set, trying default path")
    configPath = '../../config.json';
}
else{
    configPath = configPath+'/collectionconfig/config.json'
}

if(!fs.existsSync(require("path").resolve(__dirname,configPath)))
{
    console.error("Unable to load Config file from location from Env Var CONFIG_PATH :"+configPath+", absolute path:"+require("path").resolve(__dirname,configPath));
    exit(1);
}

const config = require(configPath)

//--------- Redis Config -------------
if(process.env.redisHost){
    config.redis.redisHost=process.env.redisHost;
}

if(process.env.redisPort){
    config.redis.redisPort=process.env.redisPort;
}

if(process.env.redisCreds){
    config.redis.redisCreds=process.env.redisCreds;
}

if(process.env.dlpRedisSentinels){
	config.redis.dlpRedisSentinels = process.env.dlpRedisSentinels;
}

if(process.env.redisSentinel){
	config.redis.redisSentinels = JSON.parse(process.env.redisSentinel);
}

if(process.env.kafkaBrokerList)
{
    config.kafka.kafkaBrokerList = process.env.kafkaBrokerList;
}

config.hmac.secret = new Buffer.from(config.hmac.secret, 'base64').toString();

module.exports = config