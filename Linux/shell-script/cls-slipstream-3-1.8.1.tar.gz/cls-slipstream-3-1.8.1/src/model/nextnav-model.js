const config = require('../config/config')
const cryptoUtil = require('../util/cryptoUtil')
const redisCache = require('../cache/redisCache')
const constants = require('../util/constants')
const logger = require('../util/logUtil')
const util    = require('util');
const metaData = require('../util/metaDataUtil')
const clsUtil = require('../util/clsUtil')

/**
 * save zaxis model to Cache
 * 
 */
async function saveModel(req, ldrCallback){
    var payload = req.body;
    
    if(typeof(payload) !== 'object'){
        throw new Error('nextnav payload is not object type') 
    }

    // generate the redis keys from imei/imsi
    var imeiKey = clsUtil.getImeiKey(constants.ZAXIS_IMEI_PREFIX, payload.imei);
    var imsiKey = (constants.ZAXIS_IMSI_PREFIX + payload.imsi);

    // encrypt imei/imsi and replace it in model
    if (payload.lat) payload.lat = await cryptoUtil.encryptSPI(payload.lat);
    if (payload.lon) payload.lon = await cryptoUtil.encryptSPI(payload.lon);

    //save to radis
    redisCache.putRecord(req, imeiKey, imsiKey, null, ldrCallback)
}

/**
 * Get zaxis model from redis with imei/imsi
 * 
 */
async function getModel(addrKey){

    // retrieve the zaxis payload with keys
    const dataStr = await redisCache.getRecord(addrKey)
    
    if(dataStr == null){
        throw new Error('No data found')
    }

    // parse it  to model object
    let dataObject = await JSON.parse(dataStr)

    // decript imei/imsi in the model
    if (dataObject.nativeData.lat) dataObject.nativeData.lat = parseFloat( await cryptoUtil.decryptSPI(dataObject.nativeData.lat) );
    if (dataObject.nativeData.lon) dataObject.nativeData.lon = parseFloat( await cryptoUtil.decryptSPI(dataObject.nativeData.lon) );

    //set confidence to 90%
    if (!dataObject.nativeData.locationConfidence) dataObject.nativeData.confidence = 90

    // send model to router
    return dataObject
}

module.exports = {
    saveModel,
    getModel
}    