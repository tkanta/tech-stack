const constants = require('../util/constants')
const logger = require('../util/logUtil')
const util    = require('util');
const nextNavModel =  require('./nextnav-model')
const elsModel =  require('./els-model')
const consUtil = require('../util/consumerUtil')
const clsUtil = require("../util/clsUtil")

async function getConsumerData(reqKey, reqVal, source, native){

    var locationData={};
    
    var key ;
    var nnav=false, els=false, helo=false;
   
    switch(source) {
        case "":
          nnav=true;
          els=true; 
          helo=true;
          break;
        case "NNAV":
          nnav=true;
          els=false; 
          helo=false;
          break;
        case "ELS":
          nnav=false;
          els=true; 
          helo=false;
          break;
        case "HELO":
          nnav=false;
          els=false; 
          helo=true;
          break;
        case "AML":
          nnav=false;
          els=true; 
          helo=true;
          break;
        default:
          break;
    }

    if(nnav)
    {
        // generate the redis keys from imei/imsi
        if(reqKey == "imsi")
        {
            var key = (constants.ZAXIS_IMSI_PREFIX + reqVal);
        }
        else  if(reqKey == "imei")
        {
            var key =  clsUtil.getImeiKey(constants.ZAXIS_IMEI_PREFIX, reqVal);
        }

        try
        {
            var response = await nextNavModel.getModel(key);
            locationData.locations = [];
            var modRes = consUtil.getZaxisLocation(response);
            locationData.locations.push(modRes);
            locationData.version = "1.1";
            if(native == "true")
            {
           
                if(!locationData.nativeData)
                    locationData.nativeData = {};
                
                locationData.nativeData.NNAV = response.nativeData;
            }
        }catch(error)
        {
            logger.printDebug("Error nnav : ", error);
        }
           
    }
    if(els)
    {
        // generate the redis keys from imei/imsi
        if(reqKey == "imsi")
        {
            var key = (constants.ELS_IMSI_PREFIX + reqVal);
        }
        else  if(reqKey == "imei")
        {
            var key =  clsUtil.getImeiKey(constants.ELS_IMEI_PREFIX, reqVal);
        }
        else if(reqKey == "msisdn")
        {
            var pattern = (constants.ELS_MSISDN_PREFIX + "*" + reqVal);
            var key = await elsModel.getKey(pattern);
        }

        try
        {
            var response = await elsModel.getModel(key);
            if(!locationData.locations)
                locationData.locations = [];
            var modRes = consUtil.getELSLocation(response);
            locationData.locations.push(modRes);
            locationData.version = "1.1";
            if(native == "true")
            {
                if(!locationData.nativeData)
                    locationData.nativeData = {};
                
                locationData.nativeData.ELS = response.nativeData;
            }
        }catch(error)
        {
            logger.printDebug("Error els : ", error);
        }
           
    }

    return JSON.stringify(locationData);

}




module.exports = {
    getConsumerData
}    