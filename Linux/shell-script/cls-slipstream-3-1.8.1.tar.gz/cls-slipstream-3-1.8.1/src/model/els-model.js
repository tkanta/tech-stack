const constants = require('../util/constants')
const cryptoUtil = require('../util/cryptoUtil')
const redisCache = require('../cache/redisCache')
const logger = require('../util/logUtil')
const util    = require('util');

const clsUtil = require("../util/clsUtil")

async function saveModel(req, ldrCallback){

    var payload = req.body;
    
    if(typeof(payload) !== 'object'){
        throw new Error('els payload is not object type') 
    }

    // generate the redis keys from imei/imsi
    var imeiKey = clsUtil.getImeiKey(constants.ELS_IMEI_PREFIX, payload.device_imei);
    var imsiKey = payload.device_imsi ? constants.ELS_IMSI_PREFIX + payload.device_imsi : null;
    var msisdnKey  = payload.device_number ? constants.ELS_MSISDN_PREFIX + payload.device_number : null;

    // encrypt imei/imsi and replace it in model
    if (payload.location_latitude) payload.location_latitude = await cryptoUtil.encryptSPI(payload.location_latitude);
    if (payload.location_longitude) payload.location_longitude = await  cryptoUtil.encryptSPI(payload.location_longitude);

    //save to radis
    redisCache.putRecord(req, imeiKey, imsiKey, msisdnKey, ldrCallback)
}

async function getModel(addrKey){

    // retrieve the zaxis payload with keys
    const dataStr = await redisCache.getRecord(addrKey)
    
    if(dataStr == null){
        throw new Error('No data found')
    }

    // parse it  to model object
    let dataObject = await JSON.parse(dataStr)

    // decript imei/imsi in the model
    if (dataObject.nativeData.location_latitude) dataObject.nativeData.location_latitude = parseFloat( await cryptoUtil.decryptSPI(dataObject.nativeData.location_latitude) );
    if (dataObject.nativeData.location_longitude) dataObject.nativeData.location_longitude = parseFloat( await cryptoUtil.decryptSPI(dataObject.nativeData.location_longitude) );

    // send model to router
    return dataObject
}

async function getKey(pattern){
    let keys = await redisCache.getKeys(pattern)

    if(keys == null || keys.length == 0) {
        throw new Error('Keys not found for the pattern')
    } 

    return keys[0];
}


module.exports = {
    saveModel,
    getModel,
    getKey
}    