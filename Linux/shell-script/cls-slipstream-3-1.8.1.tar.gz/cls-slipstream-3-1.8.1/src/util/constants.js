module.exports = {
    //----- redis key prefix ----
    ZAXIS_IMEI_PREFIX : 'collection:zaxis:imei:',
    ZAXIS_IMSI_PREFIX : 'collection:zaxis:imsi:',

    ELS_IMEI_PREFIX : 'collection:els:imei:',
    ELS_IMSI_PREFIX : 'collection:els:imsi:',
    ELS_MSISDN_PREFIX : 'collection:els:msisdn:',

    //----- TYPES -----
    MALFORMED_REQUEST : 'Malformed Request',
    BAD_REQUEST : 'Bad Request',
    NO_DATA : 'No Data',
    UNAUTHORIZED : 'Unauthorized',
    INTERNAL_SERVER_ERROR: 'Internal server error',
    HMAC_VALIDATION_ERROR: 'Hmac validation error',
    
    //------ Messages ----
    MALFORMED_REQUEST_MSG : 'Malformed Request',
    MISSING_AUTHORIZATION_HEADER: 'Missing authorization header',
    MISSING_USERNAME_OR_PASSWORD: 'Missing username or password',
    INVALID_USERNAME_OR_PASSWORD: 'Invalid username or password',
    MISSING_OR_BADLY_FORMED: '400 Bad Request. Missing or badly formed : ',
    BADLY_FORMED: '400 Bad Request. Badly formed : ',
    NO_VALID_DATA_FOUND_FOR:'404 No valid data found for : ',
    NO_DATA_RETRIEVED:'No data retrieved',
    EMPTY_REQUEST_BODY: 'Empty request body',

    BAD_REQUEST_CODE: 400,
    INTERNAL_SERVER_ERROR_CODE: 500,
    SUCCESS_CODE: 200,
    
    //----- LDR Internal Errors -----
    INTERNAL_SUCCESS: 0,
    VALIDATION_FAILED: 1,
    DATA_MISSING: 2,
    NO_LOCATION_AVAILABLE: 3,
    REDIS_ERROR: 4
    
}