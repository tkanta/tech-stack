const util    = require('util');
const path    = require('path');
const fs      = require('fs');
const config = require('../config/config');
const url     = require('url');
const os      = require('os');
const sprintf = require('sprintf-js').sprintf;


var myArgs = process.argv.slice(2);
var cfgSource = myArgs[0]+'';
var cfgOptions = myArgs[1];
//console.log("myArgs: ", myArgs);
//console.log("cfgSource: ", cfgSource);
//console.log("cfgOptions: ", cfgOptions);
var hcName = 'collectionserver';
if (cfgSource != 'undefined' && cfgSource != null) {
  hcName = path.basename(cfgSource,".json");
  if (isDir(cfgSource)) {
    hcName = path.basename(cfgSource,".d");
  }
}

/*
config.runDaemon=true;
config.debug=true;
config.logTransactions=true;
*/

//FOR simple-node-logger
//replace this with modern syslog in package.json
////"simple-node-logger": "^18.12.24"

var syslog ;
if('Windows_NT' === os.type()){
  syslog = require('simple-node-logger').createSimpleLogger();
  syslog.setLevel('warn');
  if (config.info)
  {
      syslog.setLevel('info');
  }

  if (config.debug)
  {
      syslog.setLevel('debug');
  }
} else {
  // FOR modern-syslog
  syslog  = require('modern-syslog');
  syslog.open(hcName, syslog.LOG_PID|syslog.LOG_ODELAY, syslog.LOG_LOCAL1);
}
var thishost=os.hostname();
if(!config.collectionLogPath)
config.collectionLogPath = "/opt/tcs/collectionserver";
mkdirp(config.collectionLogPath);
collectionLogFile=thishost+'-collectionServer.log';

function printDebug(message) {
    if (!config.debug) return;
    syslog.log(syslog.LOG_DEBUG,util.format("TCS %s %s", hcName, message));
    if (!config.runDaemon) console.log("DEBUG ", message);
  }
  function printInfo(message) {
    syslog.log(syslog.LOG_INFO,util.format("TCS %s %s", hcName, message));
    if (!config.runDaemon) console.log("INFO ", message);
  }
  
  function printWarn(message) {
    syslog.log(syslog.LOG_WARNING,util.format("TCS %s %s", hcName, message));
    console.error("WARNING ", message);
  }

  function printError(message) {
      syslog.log(syslog.LOG_ERROR,util.format("TCS %s %s", hcName, message));
      console.error("ERROR ", message);
  }

  function collectionLog(req, operation, user, playID, resultCode, resultMessage, playbook) {
    if(!user)
    {
      if(req.loggedin_user)
        user=req.loggedin_user;
        else
        user="";
    }
    servicePath = "";
    if(req.url)
    {
      if((url.parse(req.url).pathname).split("/").length >= 3)
      servicePath = (url.parse(req.url).pathname).split("/")[3];
      else
      servicePath = (url.parse(req.url).pathname).split("/")[1];
    }
    else{
      servicePath = req;
    }

    remoteHost = "";
    if(req.connection && req.connection.remoteAddress)
      remoteHost = req.connection.remoteAddress;

    printDebug(util.format("in collectionLog for %s user: %s\n", servicePath, user));
     if (!config.logTransactions)  return;
     var myDate = new Date();
     var isoDate = sprintf("%d-%02d-%02d %02d:%02d:%02d",myDate.getFullYear(),(myDate.getMonth()+1),myDate.getDate(), myDate.getHours(), myDate.getMinutes(), myDate.getSeconds());
     var logMsg=util.format("%s|%s|%s|%s|%s|%s|%s|%s|%s|%s\n", thishost, isoDate, remoteHost, user, servicePath, operation, resultCode, resultMessage, playbook, remoteHost);
     fs.appendFile(path.join(config.collectionLogPath,collectionLogFile),logMsg, (error) => {
       if (error != null) {
          syslog.log(syslog.LOG_WARNING,util.format('TCS %s Error writing %s: %j', hcName, collectionLogFile, error));
       }
     });
   }
    
  function isDir(dpath) {
    try {
      if (fs.existsSync(dpath) && fs.lstatSync(dpath).isSymbolicLink()) dpath = fs.realpathSync(dpath)
      if(fs.lstatSync(dpath).isDirectory()) return true;
    } catch(e) {
      return false;
    }
  }

  
  function mkdirp(dirname) {
    dirname = path.normalize(dirname).split(path.sep);
    dirname.forEach((sdir,index)=>{
        var pathInQuestion = dirname.slice(0,index+1).join(path.sep);
        if((!isDir(pathInQuestion)) && pathInQuestion) fs.mkdirSync(pathInQuestion);
    });
}

  module.exports = {
    printDebug,
    printInfo,
    printWarn,
    printError,
    collectionLog
    }