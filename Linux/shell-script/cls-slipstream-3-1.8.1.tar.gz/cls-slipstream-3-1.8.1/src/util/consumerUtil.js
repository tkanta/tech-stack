const { horizUncertainty, elsConfidence } = require('../config/config')

/**
 * Get source agnostic els location
 * @param {*} elsLoc 
 */
function getELSLocation(elsLocData){
    
    if(typeof(elsLocData) !== 'object'){
        throw new Error('els data is not object type') 
    }

    let elsLoc = elsLocData.nativeData;
    //empty ELS location object
    let location = {}
    
    //locSource
    location.locSource = "ELS"
    
    //imsi
    if(elsLoc.device_imsi)  location.imsi =  elsLoc.device_imsi
    
    //imei
    if(elsLoc.device_imei) location.imei =  elsLoc.device_imei
    
    //lat
    if(elsLoc.location_latitude) location.lat =  elsLoc.location_latitude
    
    //lon
    if(elsLoc.location_longitude) location.lon =  elsLoc.location_longitude
    
    //horizUncert
    if(elsLoc.location_accuracy) 
        location.horizUncert =  parseFloat(elsLoc.location_accuracy)
    else
        location.horizUncert = parseFloat(horizUncertainty)

    //alt
    if(elsLoc.location_altitude) location.alt =  parseFloat(elsLoc.location_altitude)
    
    //vertUncert
    if(elsLoc.location_vertical_accuracy) location.vertUncert =  parseFloat(elsLoc.location_vertical_accuracy)
    
    //conf
    if(elsLoc.location_confidence) 
        location.conf = parseInt(elsLoc.location_confidence*100)
    else
        location.conf = parseInt(elsConfidence*100)   
    
    //locTime
    if(elsLoc.location_time) location.locTime =  parseInt(elsLoc.location_time)
    
    //locTech
    if(elsLoc.location_source) location.locTech =  elsLoc.location_source

    //mdn/msisdn
    if(elsLoc.device_number) location.mdn =  elsLoc.device_number

    //velSpeed
    if(elsLoc.location_speed) location.velSpeed =  parseFloat(elsLoc.location_speed)
    
    //deviceModel
    if(elsLoc.device_model) location.deviceModel =  elsLoc.device_model
    
    //velBearing
    if(elsLoc.location_bearing) location.velBearing =  parseFloat(elsLoc.location_bearing)

    //receiveTime
    if(elsLocData.metaData.receivedTime) location.receivedTime = Date.parse(elsLocData.metaData.receivedTime);

    //ubp - not present

    return location
}


/**
 * Get source agnostic zaxis location
 * @param {*} zaxisLoc 
 */
function getZaxisLocation(zaxisLocData){

    if(typeof(zaxisLocData) !== 'object'){
        throw new Error('zaxis data is not object type') 
    }
    let zaxisLoc = zaxisLocData.nativeData;
    //empty ZAXIS location object
    let location = {}

    //locSource
    location.locSource = "NNAV"
    
    //imsi
    if(zaxisLoc.imsi) location.imsi =  zaxisLoc.imsi
    
    //imei
    if(zaxisLoc.imei) location.imei =  zaxisLoc.imei
   
    //lat
    if(zaxisLoc.lat) location.lat =  zaxisLoc.lat
    
    //lon
    if(zaxisLoc.lon) location.lon =  zaxisLoc.lon
    
    //horizUncert
    if(zaxisLoc.locationUnc) 
        location.horizUncert =  zaxisLoc.locationUnc
    else
        location.horizUncert =  horizUncertainty
   
    //alt
    if(zaxisLoc.alt) location.alt =  zaxisLoc.alt
    
    //vertUncert
    if(zaxisLoc.altUnc) location.vertUncert =  zaxisLoc.altUnc
    
    //conf
    if(zaxisLoc.locationConfidence) 
        location.conf =  zaxisLoc.locationConfidence
    else
        location.conf = 90
    
    //locTime
    if(zaxisLoc.posTimestamp) location.locTime =  zaxisLoc.posTimestamp

    //locTech
    if(zaxisLoc.locationSource) location.locTech = zaxisLoc.locationSource
    
    //ubp
    if(zaxisLoc.ubp) location.ubp =  zaxisLoc.ubp

    //mdn
    if(zaxisLoc.mdn) location.mdn = zaxisLoc.mdn

    if(zaxisLoc.altConfidence) location.altConf = zaxisLoc.altConfidence

    //receiveTime
    if(zaxisLocData.metaData.receivedTime) location.receivedTime = Date.parse(zaxisLocData.metaData.receivedTime);
    //velBearing - not present
    //velSpeed - not present
    //deviceModel - not present
    
    return location
}


module.exports = {
    getELSLocation,
    getZaxisLocation
}
