
function createErrorResponse(errCode, errType, errors){
    
    if(typeof errors === 'object' && errors !== null){
        errors = [...errors]
    }else if(typeof errors === 'string' && errors !== ''){
        errors = [errors]
    }else {
        errors = []
    }

    return {errCode,errType,errors}
}

module.exports = {
    createErrorResponse
}