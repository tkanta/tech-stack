var crypto = require('crypto');
const util    = require('util');
const config = require('../config/config')
const logger = require('../util/logUtil')

var cryptoKey = makeCryptoKey(config.crypto.cryptoKeyMap);
var spiKey = Buffer.alloc(32);
spiKey = Buffer.concat([Buffer.from(cryptoKey, 'utf8')], spiKey.length);
var iv = Buffer.alloc(16, 0);



function encryptSPI(text) {
  
  return new Promise(function (resolve, reject){

    var cipher = crypto.createCipheriv(config.crypto.cryptoAlgorithm,spiKey, iv)
    var crypted = cipher.update(Buffer.from(text.toString(),'utf8'),'utf8','hex')
    crypted += cipher.final('hex');
    
    resolve(crypted)
  })
  
}

function decryptSPI(hashString) {
  
  return new Promise(function (resolve, reject){
    var decipher = crypto.createDecipheriv(config.crypto.cryptoAlgorithm,spiKey, iv)
    var dec = decipher.update(hashString,'hex','utf8')
    dec += decipher.final('utf8');

    resolve(dec)
 })

}




// function encryptSPI(text) {
    
//     spiData=text.toString();
//     logger.printDebug(util.format("encryptSPI %s with %s (%s)  %s", spiData, typeof spiData, config.cryptoAlgorithm,cryptoKey));
    
//     var cipher = crypto.createCipheriv(config.crypto.cryptoAlgorithm,spiKey, iv)
//     var crypted = cipher.update(Buffer.from(text.toString(),'utf8'),'utf8','hex')
//     crypted += cipher.final('hex');
    
//     logger.printDebug(util.format("encryptSPI encoded %s to %s", text, crypted));
    
//     return crypted;
// }

// function decryptSPI(hashString) {
    
//     logger.printDebug(util.format("decryptSPI %s with %s %s", hashString, config.crypto.cryptoAlgorithm,cryptoKey));
    
//     var decipher = crypto.createDecipheriv(config.crypto.cryptoAlgorithm,spiKey, iv)
//     var dec = decipher.update(hashString,'hex','utf8')
//     dec += decipher.final('utf8');
    
//     logger.printDebug(util.format("decryptSPI Decoded %s to %s", hashString, dec));
    
//     return dec;
// }



function makeCryptoKey(keyMap) {
    //
    // This function will eventually use the clues in the keyMap to build
    // the key used to decrypt the secrets.
    //
    return keyMap;
}

  module.exports = {
    encryptSPI,
    decryptSPI
  }