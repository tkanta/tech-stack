#!/usr/bin/env node
'use strict';

//
// This script will update the redis user information.
// The user information will be stored in redis as a hash under the key
// collection:users:<username>
//   "user",
//   "pass"
//   "clientID",
//   "authData"
//

var ArgumentParser = require('argparse').ArgumentParser;
//const bcrypt   = require('bcrypt');
var fs     = require('fs');
var os     = require('os');
var path   = require('path');
var util   = require('util');
var uuid   = require('uuid');
const extend  = require('extend');
const Redis   = require('ioredis');


var rc = 0;
var users = [];
var userList = [];

var csClient=null;

var parser = new ArgumentParser({
  version: '0.0.1',
  addHelp: true,
  description: 'Update dlp users store'
});

parser.addArgument([ '--add' ], { action: 'storeTrue', help: 'add credentials to userfiles' });
parser.addArgument([ '--update' ], { action: 'storeTrue', help: 'update credentials to userfiles' });
parser.addArgument([ '--del' ], { action: 'storeTrue', help: 'delete credentials to userfiles' });
parser.addArgument([ '--debug' ], { action: 'storeTrue', defaultValue: false, help: 'delete credentials to userfiles' });
parser.addArgument([ '--test' ], { action: 'storeTrue', help: 'check user credentials for user' });
parser.addArgument([ '--list' ], { action: 'storeTrue', help: 'List all users' });
parser.addArgument([ '--type' ], {  help: 'The namespace for adding the user', defaultValue: 'collectionServer' });
parser.addArgument([ '--redisNode' ], { help: 'The list of etcd nodes in the cluster', defaultValue: '127.0.0.1' });
parser.addArgument([ '--redisPort' ], { help: 'The list of etcd nodes in the cluster', defaultValue: '6379' });
parser.addArgument([ '--name' ], { help: 'The list of etcd nodes in the cluster', defaultValue: 'mymaster' });
parser.addArgument([ '--redisCreds' ], { help: 'The list of etcd nodes in the cluster', defaultValue: 'ZGxwOmRscHJlZGlzCg==' });
parser.addArgument([ '--redisSentinels' ], { help: 'The list of etcd nodes in the cluster' });
parser.addArgument([ '--clientID' ], { help: 'The value for the clientID field for the user' });
parser.addArgument([ '--authData' ], { help: 'The value for the authData field for the user' });
parser.addArgument([ '--passwd' ], { help: 'user password' });
parser.addArgument([ '--credentials' ], { help: 'base64 encoded user:password pair' });
parser.addArgument([ 'user' ], { help: 'user name', nargs: "?" });

var args;
args = parser.parseArgs();

if (args.debug) {
  console.log('-----------');
  console.dir(args);
  console.log('-----------');
}
function fileExists(filePath) {
  try  {
    return fs.statSync(filePath).isFile();
  } catch (e) {
    if (e.code == 'ENOENT') {
      return false;
    }
    if (args.debug) console.log("Exception fs.statSync (" + filePath + "): " + e);
    throw e;
  }
}

async function listUsers(userList) {
  if (args.debug) console.log("listUsers getting User List from: " + userList);

  if (!userList) {
    console.log(util.format("No %s Users.", args.type));
    return; 
  } 
  if (args.debug) console.log("listUsers userList: " + userList);

  if (userList.length > 0) {
    var myUsers=[];
    console.log(util.format("listUserListing %s Users:", args.type));
    // get the list of users and display user information
    var pending = userList.length;
    userList.forEach(function(item) {
      console.log(util.format("listUsers getting processing for: %s (%s)", item, pending));
      const myKey="collection:users:"+item;
      csClient.hgetall(myKey, function(err, result) {
        console.log(util.format("listUsers getting data for: %s %j (%j)", item, result, err ));
        if (result) myUsers.push(result); 
        if (!--pending) {
          console.log(JSON.stringify(myUsers,null,2));
        }
      });
    });
  } else {
    console.log(util.format("No %s Users.", args.type));
  }
}

async function updateUser(userData, userKey) {

  if (args.debug) console.log(util.format("updating user %s using password [%s]", args.user, args.passwd)); 
  // //var passhash = bcrypt.hashSync(args.passwd, 10);
  var passbase64 = Buffer.from(args.passwd).toString('base64');
  if (args.add) var userData={
    "user": args.user
  } 

  var newData={};

  if (args.add) {
    newData.clientID = args.clientID || uuid.v1();
    newData.authData = args.authData || null;
    newData.pass     = passbase64; 
  } 
  if (args.clientID) newData.clientID = args.clientID;
  if (args.authData) newData.authData = args.authData;
  if (args.passwd) newData.pass = passbase64;

  if (args.debug) console.log(util.format("updateUser userData (%s): %s ", userKey, JSON.stringify(userData,null,2)));
  if (args.debug) console.log(util.format("updateUser new userData: %s", JSON.stringify(newData,null,2)));
  extend(true, userData, newData);
  if (args.debug) console.log(util.format("updateUser extended userData: %s", JSON.stringify(userData,null,2)));

  // update the redis record for the user.
  csClient.hmset(userKey, userData);
  if (args.add) {
    var listKey="collection:userList";
    csClient.sadd(listKey, args.user);
  } 

} 

function delUser(userData, userKey) {
  if (!userData) {
    console.log(util.format("Error: User %s does not exist\n",args.user));
    rc=1;
  } else {
    var listKey="collection:userList"
    csClient.srem(listKey, args.user);
    csClient.del(userKey);
  }
} 

function testUser(userData) { 
  if (args.debug) console.log(util.format("testing %s using password %s", args.user, args.passwd)); 
  if (args.debug) console.log(util.format("testing %s using data %j", args.user, JSON.stringify(userData,null,2))); 
  if (!userData) {
    console.log("User "+args.user+" does not exist.");
    rc=1;
  } else {
    //var authStatus=bcrypt.compareSync(args.passwd, userData.pass);
    var pwd = Buffer.from(userData.pass, 'base64').toString('ascii'); 
    var authStatus= args.passwd == pwd;
    if (authStatus) {
      console.log("User "+args.user+" authentication passed.");
      rc=0;
    } else {
      console.log("User "+args.user+" authentication failed.");
      rc=1;
    }
  } 
} 

//
// Main Process
//

process.on('unhandledRejection', (err) => { 
  console.error(err);
  process.exit(1);
})

async function doMain(callback) {
  // set the operation based on cli switches
  var operation="LST";
  
  if (args.add) operation="ADD";
  if (args.update) operation="UPD";
  if (args.del) operation="DEL";
  if (args.test) operation="TST";
  
  // if credentials are used, update the user and password arguments.
  if (args.credentials) {
     const authCreds = Buffer.from(args.credentials, 'base64').toString('ascii').trim();
     const [authUser, basicPass] = authCreds.split(':');
     args.passwd = basicPass; 
     args.user = authUser; 
     if (args.debug) console.log(util.format("Creating info from credentials: user: %s pass: %s", args.user, args.passwd));
  } 
  
  // test to see if the requisite data is available for the operation
  if ((args.add || args.update || args.del || args.test) && (!args.user)) { 
    console.log(util.format("The %s operation requires a user name", operation));
    parser.printHelp()
    callback(2);
  }
  
  if ((args.add || args.update || args.test) && (!args.passwd)) { 
    console.log(util.format("The %s operation requires a pasword", operation));
    parser.printHelp()
    callback(3);
  }
  
  // Attach to redis DB backend
  //TODO: Need to handle redis connection error throughout
  //TODO: Need to set an access password so that we can connect via interfaces other
  //      than localhost
  //Note: when connecting to redis via a Kubernetes HA redis service the host for
  //      the master would be <redis-service-name>-0
  const redisCreds = Buffer.from(args.redisCreds, 'base64').toString('ascii');
  const redisToken = redisCreds.split('\n')[0];
  const [redisUser, redisPass] = redisToken.split(':');
  redisPass.replace(/\n/g,'');
  if (args.debug) {
    console.log(util.format("Redis Password: %s", redisPass));
  } 
  /*
  * Change to ioredis
   var redisOptions = {
     password: redisPass,
   }
   csClient = redis.createClient(args.redisPort, args.redisHost, redisOptions);
  */
  
//  var csClient=null;
  if (args.redisSentinels) {
    csClient = new Redis({
      sentinels: JSON.parse("[{\"host\" : \""+args.redisNode+"\", \"port\" : "+args.redisPort+"}]"), 
      name: args.name
    });
  } else {
    if (args.debug) {
      console.log ("creating Redis client");
    }
    csClient = new Redis({
      port: args.redisPort,
      host: args.redisNode
    });
    
  }
  
  await csClient.client('setname',"dlpuser-redis"); 
  
  if (args.debug) {
    console.log ("Getting client information");
  
    const getClient = csClient.pipeline();
    getClient.client('id');
    getClient.client('getname');
    let results = await getClient.exec();
    console.log(util.format('collectionServer redis client %s: %s', results[0], results[1]));
  
  } 
  var userData={};
  
  if (args.update || args.add || args.del || args.test) { 
    // get user data
    var userKey="collection:users:"+args.user;
    let myData = await csClient.hgetall(userKey);
    if (myData) userData = myData;
    console.log(util.format('collectionServer userData: %j', userData));
  } 
  
  const listKey="collection:userList";
  let userList = await csClient.smembers(listKey);
  if (args.debug) console.log(util.format("collectionServer userList: %s", userList));

  switch(operation) {
    case 'ADD':
      updateUser(userData, userKey);
      break;
    case 'UPD':
      updateUser(userData, userKey);
      break;
    case 'DEL':
      delUser(userData, userKey);
      break;
    case 'TST':
      testUser(userData);
      break;
    case 'LST':
      listUsers(userList);
      break;
    default:
      parser.printHelp()
      callback(1);
  
  }
  if (users[args.user] && !args.list) {
    console.log(util.format("User Data:\n%s", JSON.stringify(users[args.user],null,2)));
  }
  callback(rc);
}

doMain(function(result){ 
  process.exit(rc);
});

