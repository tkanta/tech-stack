const logger = require('./logUtil')
const kafka = require('../voyager/kafka')
const els_ldr = require('../voyager/els_ldr');
const nnav_ldr = require('../voyager/nnav_ldr')
const metaData = require('./metaDataUtil');

async function createAndSendLDRfromELS(req, responseStatus, internalResult, isEncrypted) {
  //Create LDR
  const ldr = await els_ldr.createELSLDR(req, isEncrypted)
  
  ldr['responseStatus'] = responseStatus;
  ldr['internalResult'] = internalResult;
  if (ldr) {
    try {
      kafka.writeLdr(ldr)
    } catch (e) {
      logger.printError(e);
    }
  }
}

async function createAndSendLDRfromNNav(req, responseStatus, internalResult, isEncrypted) {
  //Create LDR
  const ldr = await nnav_ldr.createNNAVLDR(req.body, req.ip, isEncrypted)

  ldr['responseStatus'] = responseStatus;
  ldr['internalResult'] = internalResult;
  if (ldr) {
    try {
      kafka.writeLdr(ldr)
    } catch (e) {
      logger.printError(e);
    }
  }
}

module.exports = {
  createAndSendLDRfromELS,
  createAndSendLDRfromNNav
}