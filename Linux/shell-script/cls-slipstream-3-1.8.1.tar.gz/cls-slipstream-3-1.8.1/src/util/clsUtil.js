const sprintf = require('sprintf-js').sprintf;
const config = require('../config/config')
const validator = require('validator')

const startTime = new Date().getTime() / 1000;
let mateUrls = []

isValidUrl = (url) => {
    return validator.isURL(url, {protocols: ['http','https'], require_protocol:true, require_host:true})
}

module.exports = {

    //------ variables ------------
    //getMateUrls : () => Array.from(mateUrls),
    getMateUrls : () => Array.from(config.serverUrls),

    //------- utility function --------
    
    // Take leading 14 digit of IMEI for storage key, if 'useLeading14DigitsOfImeiForKey' flag is true
    getImeiKey : ( prefix, imei) => {
          
          if(imei){
            return (config.useLeading14DigitsOfImeiForKey 
                ? (prefix + imei.substr(0,14)) 
                : (prefix + imei))
          }
          
          return null;
            
    },

    //check empty object
    isEmptyObject : (value) => {
        return Object.keys(value).length === 0 && value.constructor === Object;
    },
    
    //calculate uptime for collection server
    getUptime : () => {
        var seconds= (new Date().getTime() / 1000) - startTime;
        var numdays = Math.floor(seconds / 86400);
        var numhours = Math.floor((seconds % 86400) / 3600);
        var numminutes = Math.floor(((seconds % 86400) % 3600) / 60);
        var numseconds = Math.floor((seconds % 86400) % 3600) % 60;
        var plural = "s";
        if (numdays == 1) plural ="";
        return sprintf("%d day%s %02d:%02d:%02d",numdays, plural, numhours, numminutes, numseconds);
    },

    updateMateUrl: (req) => {
        if(mateUrls.length === 0){
            const host = req.headers.host
            const urls = config.serverUrls
            if(urls){
                urls.forEach(url => {
                    const u = validator.trim(url)
                    if(!u.includes(host) && isValidUrl(u)){
                        mateUrls.push(u)
                    }
                })
            } 
        }
         
    }


}    