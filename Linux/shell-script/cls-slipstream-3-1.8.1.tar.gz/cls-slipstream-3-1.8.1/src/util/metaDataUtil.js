
function getMetaData() {
    var returnData = {};
    returnData.receivedTime = new Date().toJSON().slice(0,19);
    return returnData;
  }

  module.exports = {
    getMetaData
    }