const retry = require('retry')
const logger = require('./logUtil')
const kafka = require('../voyager/kafka')
const https = require('https')
const keepAliveAgent = new https.Agent({ keepAlive: false, maxSockets: 100 });

function postJsonWithRetry(req, url, retryCount) {
    const urlObj = new URL(url)
    const hostname =  urlObj.hostname.slice()
    const pathname =  urlObj.pathname.slice()
    const postOperation = retry.operation({
      retries: retryCount,
    });

    var data = new URLSearchParams(req.body).toString();

    const config = {
      hostname: hostname,
      port: 443,
      path: pathname,
      method: 'POST', 
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'sync': false
      }
    }

    config.agent = keepAliveAgent;
    
    postOperation.attempt(async (currentAttempt) => {
        //console.log('sending request: ', currentAttempt, ' attempt');
     
        const req = https.request(config);
        req.on('error', (err) => {
            const errMsg = err.message ? err.message : "mate server not reachable."
            logger.collectionLog(req, "POST", "", "", "500", "Mate Sync Failure", errMsg)
            kafka.eventLogger.logEvent('ZAXIS-MateServerNotReachable', 'Error:'+errMsg);
            if (postOperation.retry(err)) { return; }
        });
        req.write(data)
        req.end();

    });      
}

module.exports = {
  postJsonWithRetry
}