const Redis = require('ioredis')
const config = require('../config/config')
const kafka = require('../voyager/kafka')
const logger = require('../util/logUtil')
const util   = require('util');
const metaData = require('../util/metaDataUtil')
const constants = require('../util/constants')

var alarm = null;

//---------- Redis Connection ------------
  let csClient  = null;

  if (config.redis.dlpRedisSentinels == true) {
    csClient = new Redis({
      sentinels: config.redis.redisSentinels.hosts,
      name: config.redis.redisSentinels.name,
      maxRetriesPerRequest: config.redis.retryConnection
    });
  } else {
    csClient = new Redis({
      port: config.redis.redisPort,
      host: config.redis.redisHost,
      maxRetriesPerRequest: config.redis.retryConnection
      //password: redisPass
    });
  }

  //----------- Syslog / Event for connection error -----------
  
  csClient.on('error', function(err) { 
    logger.printDebug(util.format("redis error : %s", err.message))
    logger.collectionLog("redis",'Redis Connection',"","","500", "Internal Server Error", err.message);
    if(alarm == null) {
      alarm = kafka.eventLogger.createAlarm('ZAXIS-RedisDatabaseUnavailable');
      alarm.raise('Redis database is unavailable');
    }
  })

  csClient.on('connect', () => {
    if(alarm != null){
      alarm.clear('Redis database connected');
      alarm = null;
    }
  })

  /**
   *  Get record from Redis using imei/imsi
   */
  async function getRecord( addrKey ) {

    try{
      const response = await csClient.get(addrKey)
      return response
    }catch(err){
      logger.printDebug(util.format("------ redis get error : %s", err))
      throw new Error(err)
    }

}

/**
 * Get key from Redis Keyspace which matches the pattern
 * @returns String key
 */
async function getKeys( pattern ) {
  try{
    let keys = await csClient.keys(pattern)
    return keys
  } catch(err) {
    logger.printDebug(util.format("------ redis get key error : %s", err))
    throw new Error(err)
  }
}

/**
 * Get redis status
 */
async function getRedisStatus(){

   return csClient.status
}

/**
 * Get User details
 */
async function getUserDetails(basicUser){

  var userKey="collection:users:"+basicUser;

  result = await csClient.hgetall(userKey);
  return result
}



/**
 * Put data record in Redis using imei/imsi key
 *
 */
 async function putRecord(req, imeiKey, imsiKey, msisdnKey, ldrCallback) {

  var elsPayload = {};
  elsPayload.metaData = metaData.getMetaData();
  // stringyfied the object model and pass it to redis
  elsPayload.nativeData = req.body;
  const dataJson = JSON.stringify(elsPayload);
  
  //------------- check json string ------------
  if(typeof(dataJson) !== 'string'){
    throw new Error('payload is not string type') 
  }

  const redisUpdate = csClient.multi();
  
  if(imeiKey){
    redisUpdate.set(imeiKey, dataJson)
    redisUpdate.expire(imeiKey, config.redis.redisRetention)
  }
  if(imsiKey){
    redisUpdate.set(imsiKey, dataJson)
    redisUpdate.expire(imsiKey, config.redis.redisRetention)
  }
  if(msisdnKey){
    redisUpdate.set(msisdnKey, dataJson)
    redisUpdate.expire(msisdnKey, config.redis.redisRetention)
  }
  
  redisUpdate.exec(function(err, resp) { 
    if (err){
      logger.printDebug(util.format("----- redis put error : %s", err));
      ldrCallback(req, constants.INTERNAL_SERVER_ERROR_CODE, constants.REDIS_ERROR, true);
    } else {
      ldrCallback(req, constants.SUCCESS_CODE, constants.INTERNAL_SUCCESS, true);
    }
  });
  
}



//------ export modules ------
module.exports = {
  getRecord,
  putRecord,
  getUserDetails,
  getRedisStatus,
  getKeys
}