const uuidv4 = require('uuid').v4
var os = require("os");
const voyager = require('node-core');
const config = require('../config/config')
const cryptoUtil = require('../util/cryptoUtil')

async function createNNAVLDR (req, ip, isEncrypted) {
    const positionReport = {
      type: 3,
      hostName: os.hostname(), 
      date: new Date().toISOString(),
      origIP: ip,
      source: voyager.getSource(config.processName),
      tid: uuidv4(),
      uri: 'coreusage://collection/nnav_push',
      rtid: req.tid,
      imsi: ('imsi' in req) ? req.imsi : "",
      imei: req.imei,
      alt: ('alt' in req) ? req.alt : "",
      altUnc: ('altUnc' in req) ? req.altUnc : "",
      lat: ('lat' in req) && isEncrypted ? parseFloat( await cryptoUtil.decryptSPI(req.lat)) : (req.lat?req.lat: ""),
      lon: ('lon' in req) && isEncrypted ? parseFloat( await cryptoUtil.decryptSPI(req.lon)) : (req.lon?req.lon:""),
      locationUnc: ('locationUnc' in req) ? req.locationUnc : "",
      posTimestamp: ('posTimestamp' in req) ? req.posTimestamp : "",
      callTimestamp: req.callTimestamp,
      deviceTimestamp: req.deviceTimestamp,
      serverTimestamp: req.serverTimestamp,
      statusCode: req.statusCode
    }
    return positionReport
}

module.exports = { createNNAVLDR }
