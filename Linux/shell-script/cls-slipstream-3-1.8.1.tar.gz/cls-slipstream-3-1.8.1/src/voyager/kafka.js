const Kafka   = require('node-rdkafka');
const util   = require('util');
//const syslog  = require('modern-syslog');
const config = require('../config/config')
const logger = require('../util/logUtil')
const voyager = require('node-core');
const { Console } = require('console');

var omStream       = null;
var elsStream       = null;
var queryStream       = null;
var eventStream    = null;
var ldrStream = null;

// OM topic
omStream = Kafka.Producer.createWriteStream({
    'metadata.broker.list': config.kafka.kafkaBrokerList
  }, 
  {}, 
  {
    topic: config.kafka.omTopic
  }
);

omStream.producer.on('event.error', (err) => {
  logger.printWarn(util.format('Kafka is down', err));
  console.error('Error in our kafka omStream :' + err);    
});

omStream.on('error', function (err) {
  logger.printWarn(util.format('Kafka is down', err));
});

// EVENT topic
eventStream = Kafka.Producer.createWriteStream({
    'metadata.broker.list': config.kafka.kafkaBrokerList
  }, 
  {}, 
  {
    topic: config.kafka.eventTopic
  }
);

eventStream.producer.on('event.error', (err) => {
  logger.printWarn(util.format('Kafka is down', err));
});

eventStream.on('error', function (err) {
  logger.printWarn(util.format('Kafka is down', err));
})

//LDR topic

ldrStream = Kafka.Producer.createWriteStream({
    'metadata.broker.list': config.kafka.kafkaBrokerList
  }, 
  {}, 
  {
    topic: config.kafka.ldrTopic
  }
);

ldrStream.producer.on('event.error', (err) => {
  logger.printWarn(util.format('Kafka is down', err));
  console.error('Error in our kafka omStream :' + err);    
});

ldrStream.on('error', function (err) {
  logger.printWarn(util.format('Kafka is down', err));
});

function writeLdr(message) {
  ldrStream.write(JSON.stringify(message) + '\n');
}

//------ OM metrics -------
var eventLogger = new voyager.Logger(config.processName, config.eventXMLpath, eventStream);
var omCounters = new voyager.MetricsMgr(config.processName, omStream, config.debug, config.kafka.matricsReportInterval, config.kafka.omInfo);
var omPostReceived = omCounters.createPegCount("CollectionServer.Post.Received");
var omPostSuccess  = omCounters.createPegCount("CollectionServer.Post.Success");
var omPostFailure  = omCounters.createPegCount("CollectionServer.Post.Failure");
var omGetReceived  = omCounters.createPegCount("CollectionServer.Get.Received");
var omGetSuccess   = omCounters.createPegCount("CollectionServer.Get.Success");
var omGetFailure   = omCounters.createPegCount("CollectionServer.Get.Failure");

module.exports = { 
  eventLogger,
  omPostReceived,
  omPostSuccess,
  omPostFailure,
  omGetReceived,
  omGetSuccess,
  omGetFailure,
  omCounters,
  writeLdr
}