const uuidv4 = require('uuid').v4
var os = require("os");
const voyager = require('node-core');
const config = require('../config/config')
const cryptoUtil = require('../util/cryptoUtil')

async function createELSLDR (req, isEncrypted) {
var body = req.body;
    const positionReport = {
      type: 3,
      hostName: os.hostname(),
      date: new Date().toISOString(),
      origIP: req.ip,
      isSyncFromMate: req.headers['sync'] == 'true' ? 1 : 0,
      source: voyager.getSource(config.processName),
      tid: uuidv4(),
      uri: 'coreusage://collection/els_push',
      version:  ('v' in body) ? body.v : "",
      thunderbirdVersion: ('thunderbird_version' in body) ? body.thunderbird_version : "",
      emergencyNumber: ('emergency_number' in body) ? body.emergency_number : "",
      activationSource: ('source' in body) ? body.source : "",
      time:  ('time' in body) ? body.time : "",
      gtLocationLatitude:  ('gt_location_latitude' in body) ? body.gt_location_latitude : "",
      gtLocationLongitude:  ('gt_location_longitude' in body) ? body.gt_location_longitude : "",
      locationTime:  ('location_time' in body) ? body.location_time : "",
      locationLatitude:  ('location_latitude' in body) && isEncrypted ? parseFloat( await cryptoUtil.decryptSPI(body.location_latitude)) : (body.location_latitude ? body.location_latitude:""),
      locationLongitude:  ('location_longitude' in body) && isEncrypted ? parseFloat( await cryptoUtil.decryptSPI(body.location_longitude)) : (body.location_longitude ? body.location_longitude:""),
      locationAltitude:  ('location_altitude' in body) ? body.location_altitude : "",
      locationAccuracy:  ('location_accuracy' in body) ? body.location_accuracy : "",
      locationVerticalAccuracy:  ('location_vertical_accuracy' in body) ? body.location_vertical_accuracy : "",
      locationBearing:  ('location_bearing' in body) ? body.location_bearing : "",
      locationSpeed:  ('location_speed' in body) ? body.location_speed : "",
      locationConfidence:  ('location_confidence' in body) ? body.location_confidence : "",
      locationSource:  ('location_source' in body) ? body.location_source : "",
      locationFloor:  ('location_floor' in body) ? body.location_floor : "",
      deviceNumber:  ('device_number' in body) ? body.device_number : "",
      deviceModel:  ('device_model' in body) ? body.device_model : "",
      deviceImei:  ('device_imei' in body) ? body.device_imei : "",
      deviceImsi:  ('device_imsi' in body) ? body.device_imsi : "",
      deviceIccid:  ('device_iccid' in body) ? body.device_iccid : "",
      cellHomeMcc:  ('cell_home_mcc' in body) ? body.cell_home_mcc : "",
      cellHomeMnc:  ('cell_home_mnc' in body) ? body.cell_home_mnc : "",
      cellNetworkMcc:  ('cell_network_mcc' in body) ? body.cell_network_mcc : "",
      cellNetworkMnc:  ('cell_network_mnc' in body) ? body.cell_network_mnc : ""
    }
    return positionReport
}

module.exports = { createELSLDR }
