#!/bin/bash

serviceVMs="${@:-service1 service2}"
ssId=1.8.1_cls_slipstream_3

is_slipstream_applied()
{
     echo "$(date -u) checking if slipstream applied in $1"
     ssh -q $1 '[ ! -d "/usr/lib/collectionServer/src-bk" ]'
}


take_backup()
{
   echo "$(date -u) back up original files in $1"
   
   ssh -q $1 '[ ! -d "/usr/lib/collectionServer/src-bk" ] && sudo mv /usr/lib/collectionServer/src  /usr/lib/collectionServer/src-bk'
   ssh -q $1 '[ ! -f "/usr/lib/collectionServer/package.json_bkup" ] && sudo mv /usr/lib/collectionServer/package.json /usr/lib/collectionServer/package.json_bkup && sudo chown collectionServer:collectionServer /usr/lib/collectionServer/package.json_bkup'

}


copy_files()
{
    echo "$(date -u) copying slipstream files to $1"

    ssh -q $1 "mkdir /tmp/${ssId}"    

    scp -qr ./src  $1:/tmp/${ssId}
    scp -q ./package.json  $1:/tmp/${ssId}

    ssh -q $1 "sudo cp -r /tmp/${ssId}/src  /usr/lib/collectionServer"
    ssh -q $1 "sudo chown -R collectionServer:collectionServer /usr/lib/collectionServer/src"

    ssh -q $1 "sudo cp /tmp/${ssId}/package.json  /usr/lib/collectionServer/package.json"
    ssh -q $1 "sudo chown collectionServer:collectionServer /usr/lib/collectionServer/package.json"

    ssh -q $1 "sudo rm -rf /tmp/${ssId}"
}

stop_server()
{
   echo "$(date -u) stopping collectionserver in $1"

   ssh -q $1 'sudo systemctl stop collectionServer'
}

restart_server()
{
   echo "$(date -u) restarting  collectionserver in $1"

   ssh -q $1 'sudo systemctl restart collectionServer'
}


########## MAIN ############

#if [ $# -ne  0 ]; then

	exit_status=0
	for serviceVM in ${serviceVMs}; do
	
	    is_slipstream_applied $serviceVM
	
	    (( exit_status |= $? ))
	          
	    #echo "$(date -u) is slipstream applied? $exit_status $([ $exit_status -eq 1 ] &&  echo 'yes' || echo 'no') "
	
	    if [ $exit_status -eq 0 ]; then
		echo "$(date -u) applying slipstream in $serviceVM "
		#stop_server $serviceVM	
	        take_backup $serviceVM 
		copy_files $serviceVM
	        restart_server $serviceVM		
	    else
		echo "$(date -u) slipstream already applied"	
	    fi 
	done
#else
#	echo "$(date -u)  No argument supplied -> Usage: ./install.sh service1 service2"
#fi


