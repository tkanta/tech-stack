#!/bin/bash

serviceVMs="${@:-service1 service2}"


is_slipstream_rolledback()
{
     echo "$(date -u) checking if slipstream already rolled back in $1"
 
     ssh -q $1 '[ -d "/usr/lib/collectionServer/src-bk" ]'
}


rollback_slipstream()
{
  echo "$(date -u)  Rolling back slipstream in $1"
  
  ssh -q $1 '[ -d "/usr/lib/collectionServer/src-bk" ] &&  sudo rm -rf /usr/lib/collectionServer/src && sudo mv /usr/lib/collectionServer/src-bk /usr/lib/collectionServer/src'
  ssh -q $1 '[ -f "/usr/lib/collectionServer/package.json_bkup" ] && sudo cp /usr/lib/collectionServer/package.json_bkup  /usr/lib/collectionServer/package.json && sudo chown collectionServer:collectionServer /usr/lib/collectionServer/package.json && sudo rm -f /usr/lib/collectionServer/package.json_bkup'
	
}

restart_server()
{
   ssh -q $1 'sudo systemctl restart collectionServer'
 
   echo $serviceVM '->  collectionServer restarted.'

}

################## MAIN #################

#if [ $# -ne 0 ]; then

        exit_status=0
        for serviceVM in ${serviceVMs}; do

            is_slipstream_rolledback $serviceVM

            (( exit_status |= $? ))

            #echo "$(date -u) is slipstream applied? $exit_status $([ $exit_status -eq 1 ] &&  echo 'yes' || echo 'no') "

            if [ $exit_status -eq 0 ]; then
                rollback_slipstream $serviceVM
                restart_server $serviceVM
            else
                echo "$(date -u) slipstream already rolled back in $serviceVM"
            fi
        done


#else
#      echo "$(date -u)  No argument supplied -> Usage: ./uninstall.sh service1 service2"
#fi

